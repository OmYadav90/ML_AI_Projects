import time
import ipywidgets


def code_and_compute_alignment_check ( code_type : str, compute_select : int ) -> [ bool ]:
    """
        Check whether code to be benchmarked is compatible with selected compute type.
        Inputs:
            code_type: 'GPU' or 'CPU'
            compute_select: selection of GPU and CPU [0], GPU only [1], and CPU only [2]
    """
    CPU_flag = False; GPU_flag = False
    if compute_select == 0:   # GPU and CPU
        CPU_flag = True
        GPU_flag = True         
    elif compute_select == 1: # GPU only
        CPU_flag = False
        GPU_flag = True
    elif compute_select == 2: # CPU only
        CPU_flag = True
        GPU_flag = False
    
    aligned_code_and_compute = ''
    
    if code_type.lower() == 'CPU'.lower() and CPU_flag:
        return True
        
    if code_type.lower() == 'GPU'.lower() and GPU_flag:
        return True

    print(f"skipping execution -- {code_type.upper()} is not in your 'compute_choice'")
    return False

class BenchmarkContext:
    """
        Times blocks of code using the systems' high resolution timer [time.perf_counter()].
        Checks whether code should run based on the user's compute selection.

        Inputs: 
            log: dictionary where results are stored
            key: custom key/tag that describes the operation being timed
            code_type: type of code to be benchmarked { GPU or CPU }
            compute_select: selection of CPU [2], GPU [1], or both [0]
        
        Returns:
            N/A -- inline update is made to the log dictionary

        e.g.
            with Bench ( log, 'train_model', compute_select ): 
                # code block to benchmarka
                train_model ( data, params )

            >>> duration of [ train_model_gpu ] = 2.4765 seconds 

    """
    def __init__( self, log, key,
                  code_type : str,
                  compute_select : int, verbose = False ):
        
        
        self.verbose = verbose
        if self.verbose: print('init method called')

        self.log = log
        self.code_type = code_type.lower()
        assert ( code_type in [ 'gpu', 'cpu'] )
        
        self.OP = key # store original key as the operation/OP label
        self.key = key + '_' + str( code_type ) # create a more verbose key appended with the code_type
        self.compute_select = compute_select

        self.start = None
        self.duration = None
        
        
        
    # runs at the start of a code block [ wrapped in BenchmarkContext ]
    def __enter__(self):
        if self.verbose: print('enter method called')        

        if self.execute_block:
            print( f'running {self.OP.upper()} on {self.code_type.upper()}' )
            self.start = time.perf_counter()
            
        return self

    # runs at the end of a code block [ wrapped in BenchmarkContext ]
    def __exit__(self, exc_type, exc_value, exc_traceback ):
        if self.verbose: print('exit method called')        
        
        if self.execute_block and exc_type is None:

            self.duration = time.perf_counter() - self.start            
            self.log.update( { self.key : self.duration })  

            print(f'duration : {round(self.duration, 4)} seconds')
        else:
            print('skipped logging' )

class GPU ( BenchmarkContext ):
    def __init__( self, log : dict , key : str, compute_select: ipywidgets.widgets.widget_selection.ToggleButtons ):        
        self.code_type = 'GPU'.lower()
        self.execute_block = code_and_compute_alignment_check ( self.code_type, compute_select.index )
        super(GPU, self).__init__( log, key, self.code_type, compute_select.index )

class CPU ( BenchmarkContext ):
    def __init__( self, log : dict, key : str, compute_select: ipywidgets.widgets.widget_selection.ToggleButtons ):
        self.code_type = 'CPU'.lower()
        self.execute_block = code_and_compute_alignment_check ( self.code_type, compute_select.index )
        super(CPU, self).__init__( log, key, self.code_type, compute_select.index )        