import os
import argparse
import logging
import torch
import torch.autograd.profiler as profiler
from collections import OrderedDict

import detectron2.utils.comm as comm
from detectron2.checkpoint import DetectionCheckpointer, PeriodicCheckpointer
from detectron2.config import get_cfg
from detectron2.data import (
    DatasetCatalog,
    MetadataCatalog,
    build_detection_test_loader,
    build_detection_train_loader,
    DatasetMapper
)
from detectron2.engine import default_argument_parser, default_setup, launch
from detectron2.evaluation import (
#     CityscapesEvaluator,
    COCOEvaluator,
    COCOPanopticEvaluator,
    DatasetEvaluators,
    LVISEvaluator,
    PascalVOCDetectionEvaluator,
    SemSegEvaluator,
    inference_on_dataset,
    print_csv_format,
)
from detectron2.modeling import build_model
from detectron2.solver import build_lr_scheduler, build_optimizer
from detectron2 import model_zoo
from detectron2.utils.events import (
    CommonMetricPrinter,
    EventStorage,
    JSONWriter,
    TensorboardXWriter,
)
import detectron2.data.transforms as T
from detectron2.structures import BoxMode
from detectron2.data.datasets import register_coco_instances
from build import *

CONFIGS_BASE = '' # ./detectron2/configs
WEIGHTS_BASE = 'detectron2://' # https://dl.fbaipublicfiles.com/detectron2/
BASE_DIR = os.environ['SM_CHANNEL_TRAIN']
IMAGES_BASE = os.environ['SM_CHANNEL_TRAIN'] + '/images'
images_list = os.listdir(IMAGES_BASE)
print(f'images base: {IMAGES_BASE} has {len(images_list)} files')

# replace this by dynamically calling model_zoo.get_checkpoint_url('COCO-Detection/faster_rcnn_X_101_32x8d_FPN_3x.yaml') for a given config

# BASE_MODELS = \
#     {'R50-C4': 
#          {'config': f'{CONFIGS_BASE}/COCO-Detection/faster_rcnn_R_50_C4_3x.yaml',
#           'weights': f'{WEIGHTS_BASE}COCO-Detection/faster_rcnn_R_50_C4_3x/137849393/model_final_f97cb7.pkl'},
#      'R101-C4': 
#          {'config': f'{CONFIGS_BASE}/COCO-Detection/faster_rcnn_R_101_C4_3x.yaml',
#           'weights': f'{WEIGHTS_BASE}COCO-Detection/faster_rcnn_R_101_C4_3x/138204752/model_final_298dad.pkl'},
#      'R50-FPN': 
#          {'config': f'{CONFIGS_BASE}/COCO-Detection/faster_rcnn_R_50_FPN_3x.yaml',
#           'weights': f'{WEIGHTS_BASE}COCO-Detection/faster_rcnn_R_50_FPN_1x/137257794/model_final_b275ba.pkl'},
#      'R101-FPN': 
#          {'config': f'{CONFIGS_BASE}/COCO-Detection/faster_rcnn_R_101_FPN_3x.yaml',
#           'weights': f'{WEIGHTS_BASE}COCO-Detection/faster_rcnn_R_101_FPN_3x/137851257/model_final_f6e8b1.pkl'},
#      'R50': # RetinaNet
#          {'config': f'{CONFIGS_BASE}/COCO-Detection/retinanet_R_50_FPN_3x.yaml',
#           'weights': f'{WEIGHTS_BASE}COCO-Detection/retinanet_R_50_FPN_3x/190397829/model_final_5bd44e.pkl'},
#      'R101': # RetinaNet
#          {'config': f'{CONFIGS_BASE}/COCO-Detection/retinanet_R_101_FPN_3x.yaml',
#           'weights': f'{WEIGHTS_BASE}COCO-Detection/retinanet_R_101_FPN_3x/190397697/model_final_971ab9.pkl'}
#     }

# model_zoo.get_checkpoint_url('COCO-Detection/faster_rcnn_X_101_32x8d_FPN_3x.yaml')


def get_evaluator(cfg, dataset_name, output_folder=None):
    """
    Create evaluator(s) for a given dataset.
    This uses the special metadata "evaluator_type" associated with each builtin dataset.
    For your own dataset, you can simply create an evaluator manually in your
    script and do not have to worry about the hacky if-else logic here.
    """
    if output_folder is None:
        output_folder = os.path.join(cfg.OUTPUT_DIR, "inference")
    evaluator_list = []
    try:
        evaluator_type = MetadataCatalog.get(dataset_name).evaluator_type
    except:
        evaluator_type = 'coco'
    if evaluator_type in ["sem_seg", "coco_panoptic_seg"]:
        evaluator_list.append(
            SemSegEvaluator(
                dataset_name,
                distributed=True,
                num_classes=cfg.MODEL.SEM_SEG_HEAD.NUM_CLASSES,
                ignore_label=cfg.MODEL.SEM_SEG_HEAD.IGNORE_VALUE,
                output_dir=output_folder,
            )
        )
    if evaluator_type in ["coco", "coco_panoptic_seg"]:
        evaluator_list.append(COCOEvaluator(dataset_name, cfg, True, output_folder))
    if evaluator_type == "coco_panoptic_seg":
        evaluator_list.append(COCOPanopticEvaluator(dataset_name, output_folder))
    if evaluator_type == "cityscapes":
        assert (
            torch.cuda.device_count() >= comm.get_rank()
        ), "CityscapesEvaluator currently do not work with multiple machines."
        return CityscapesEvaluator(dataset_name)
    if evaluator_type == "pascal_voc":
        return PascalVOCDetectionEvaluator(dataset_name)
    if evaluator_type == "lvis":
        return LVISEvaluator(dataset_name, cfg, True, output_folder)
    if len(evaluator_list) == 0:
        raise NotImplementedError(
            "no Evaluator for the dataset {} with the type {}".format(dataset_name, evaluator_type)
        )
    if len(evaluator_list) == 1:
        return evaluator_list[0]
    return DatasetEvaluators(evaluator_list)



def str_to_steps(str_steps):
    steps_in_str_list = str_steps.split(',')
    steps_in_int_list = [int(i) for i in steps_in_str_list] 
    return steps_in_int_list


def setup(args):
    """
    Create configs and perform basic setups.
    """    
    cfg = get_cfg()
    
    cfg.merge_from_file(f'{CONFIGS_BASE}{args.model_config}')
    cfg.merge_from_list(args.opts)
    weight_path = model_zoo.get_checkpoint_url(args.model_config)
    cfg.MODEL.WEIGHTS = weight_path

    cfg.DATASETS.TRAIN = ('birds_train',)
    cfg.DATASETS.TEST = ('birds_val',)  
    cfg.DATALOADER.NUM_WORKERS = args.num_dataloader_workers    
    cfg.SOLVER.IMS_PER_BATCH = args.ims_per_batch
    cfg.SOLVER.BASE_LR = args.base_lr
    cfg.SOLVER.GAMMA = args.gamma
    cfg.SOLVER.MAX_ITER = args.num_iters
    cfg.SOLVER.STEPS = str_to_steps(args.lr_steps)
    cfg.TEST.EVAL_PERIOD = int(cfg.SOLVER.MAX_ITER * args.eval_rate)
    cfg.OUTPUT_DIR= os.environ['SM_OUTPUT_DATA_DIR']

    ## used to sample a subset of proposals coming out of RPN to calculate cls and reg loss during training. 
    ## Calculating loss on all RPN proposals isn't computationally efficient.
    cfg.MODEL.ROI_HEADS.BATCH_SIZE_PER_IMAGE = (
        args.rpn_batch_size
    )  

    num_classes = args.sample_size if args.sample_size > 0 else 200
    cfg.MODEL.ROI_HEADS.NUM_CLASSES = num_classes
    #     if args.model_arch in ['R50', 'R101']:

    if args.model_config.split('/')[-1].split('_')[0]=='retinanet':
        cfg.MODEL.RETINANET.NUM_CLASSES = num_classes
        
    if (args.spot_ckpt!='')&(args.spot_ckpt is not None):
        os.makedirs('/opt/ml/checkpoints', exist_ok=True)
        os.system(f"aws s3 cp {args.spot_ckpt} /opt/ml/checkpoints/{args.spot_ckpt.split('/')[-1]}")
        cfg.MODEL.WEIGHTS = f"/opt/ml/checkpoints/{args.spot_ckpt.split('/')[-1]}"
        
    print(f'Model num classes: {cfg.MODEL.ROI_HEADS.NUM_CLASSES}')
#    cfg.MODEL.ROI_HEADS.SCORE_THRESH_TEST = 0.5

    cfg.freeze()
    default_setup(
        cfg, args
    )  # if you don't like any of the default setup, write your own setup code
    return cfg




def do_test(cfg, model ):
    results = OrderedDict()
    for dataset_name in cfg.DATASETS.TEST:
        data_loader = build_detection_test_loader(cfg, dataset_name)
        evaluator = get_evaluator(
            cfg, dataset_name, os.path.join(cfg.OUTPUT_DIR, "inference", dataset_name)
        )
        results_i = inference_on_dataset(model, data_loader, evaluator)
        results[dataset_name] = results_i
        if comm.is_main_process():
            print("Evaluation results for {} in csv format:".format(dataset_name))
            print_csv_format(results_i)
    if len(results) == 1:
        results = list(results.values())[0]
    return results


def do_train(cfg, model, pin_memory=True, resume=False):
    model.train()
    torch.autograd._enable_profiler
    optimizer = build_optimizer(cfg, model)
    scheduler = build_lr_scheduler(cfg, optimizer)

    checkpointer = DetectionCheckpointer(
        model, cfg.OUTPUT_DIR, optimizer=optimizer, scheduler=scheduler
    )
    start_iter = (
        checkpointer.resume_or_load(cfg.MODEL.WEIGHTS, resume=resume).get("iteration", -1) + 1
    )
    max_iter = cfg.SOLVER.MAX_ITER

    periodic_checkpointer = PeriodicCheckpointer(
        checkpointer, cfg.SOLVER.CHECKPOINT_PERIOD, max_iter=max_iter
    )

    writers = (
        [
            CommonMetricPrinter(max_iter),
            JSONWriter(os.path.join(cfg.OUTPUT_DIR, "metrics.json")),
            TensorboardXWriter(cfg.OUTPUT_DIR),
        ]
        if comm.is_main_process()
        else []
    )

    # compared to "train_net.py", we do not support accurate timing and
    # precise BN here, because they are not trivial to implement
#     data_loader = build_detection_train_loader(cfg)
    data_loader = build_detection_train_loader(cfg, pin_memory,
        mapper=DatasetMapper(cfg, is_train=True, 
                             augmentations=[
                                 T.RandomFlip(horizontal=True, vertical=False, prob=0.5),
                                 T.RandomApply(T.RandomCrop('relative_range', (0.9, 0.9)), prob=0.25),
                                 T.RandomApply(T.RandomRotation(angle=[-25,25], expand=True, center=None,
                                                                         sample_style='range'), prob=0.25),
                                 T.RandomApply(T.RandomBrightness(0.8, 1.2), prob=0.25)
                             ]
                            )
#                             )
    )

#        T.Resize((1024, 1024)),
#        T.RandomSaturation(.75,1.25)
# T.RandomContrast(0.8, 3)

    print("Starting training from iteration {}".format(start_iter))
    # gets here and then fails 
    with EventStorage(start_iter) as storage:
        for data, iteration in zip(data_loader, range(start_iter, max_iter)):
#             print(data.shape)
            iteration = iteration + 1
            storage.step()

            loss_dict = model(data)
            losses = sum(loss_dict.values())
            assert torch.isfinite(losses).all(), loss_dict

            loss_dict_reduced = {k: v.item() for k, v in comm.reduce_dict(loss_dict).items()}
            losses_reduced = sum(loss for loss in loss_dict_reduced.values())
            if comm.is_main_process():
                storage.put_scalars(total_loss=losses_reduced, **loss_dict_reduced)

            optimizer.zero_grad()
            losses.backward()
            optimizer.step()
            storage.put_scalar("lr", optimizer.param_groups[0]["lr"], smoothing_hint=False)
            scheduler.step()

            if (
                cfg.TEST.EVAL_PERIOD > 0
                and iteration % cfg.TEST.EVAL_PERIOD == 0
                and iteration != max_iter
            ):
                do_test(cfg, model)
                # Compared to "train_net.py", the test results are not dumped to EventStorage
                comm.synchronize()
#             if iteration%2000==0:
#                 try:
#                     torch.save(model.state_dict(), f'{cfg.OUTPUT_DIR}/model_{iteration}.pth')
#                 except:
#                     print('save failed')

            if iteration - start_iter > 5 and (iteration % 20 == 0 or iteration == max_iter):
                for writer in writers:
                    writer.write()
            periodic_checkpointer.step(iteration)
            
            
# def main(args):
#     if args.sample_size > 0:
#         val_file = f'{BASE_DIR}/samples_birds_{args.sample_size}_val.json'
#         train_file = f'{BASE_DIR}/samples_birds_{args.sample_size}_train.json'
#         test_file = f'{BASE_DIR}/samples_birds_{args.sample_size}_test.json'
#     else:
#         val_file = f'{BASE_DIR}/instances_birds_val.json'
#         train_file = f'{BASE_DIR}/instances_birds_train.json'
#         test_file = f'{BASE_DIR}/instances_birds_test.json'

#     register_coco_instances('birds_train', {}, image_root=IMAGES_BASE, json_file=train_file)
#     register_coco_instances('birds_val', {}, image_root=IMAGES_BASE, json_file=val_file)
#     register_coco_instances('birds_test', {}, image_root=IMAGES_BASE, json_file=test_file)

#     cfg = setup(args)
# #     print(cfg)

#     model = build_model(cfg)
#     logger.info("Model:\n{}".format(model))
#     if args.eval_only:
#         DetectionCheckpointer(model, save_dir=cfg.OUTPUT_DIR).resume_or_load(
#             cfg.MODEL.WEIGHTS, resume=args.resume
#         )
#         return do_test(cfg, model)

#     distributed = comm.get_world_size() > 1
#     if distributed:
#         if args.ddp==1:
#             print('Using Distributed Data Parallel')
#             dist.init_process_group("nccl", rank=comm.get_rank(), world_size=comm.get_world_size())
#             model = DistributedDataParallel(
#                 model, device_ids=[comm.get_local_rank()], broadcast_buffers=False
#             )
#         else:
#             print('Using standard Data Parallel')
#             num_gpus = int(os.environ['SM_NUM_GPUS'])
#             devices = np.arange(num_gpus).tolist()
#             model = torch.nn.DataParallel(model, device_ids=[comm.get_local_rank()])

#     do_train(cfg, model, args.pin_memory) # logger
#     return do_test(cfg, model)

def birds_dataset(ann_file):
    with open(ann_file) as json_file:
        birds_json = json.load(json_file)
    return birds_json


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dist_url", type=str, default='tcp://127.0.0.1:49152')
#    parser.add_argument("--config_file", type=str)
    parser.add_argument('--model_config', type=str, default='/opt/ml/code/detectron2/configs/COCO-Detection/faster_rcnn_X_101_32x8d_FPN_3x.yaml')
#     parser.add_argument('--')
    parser.add_argument('--ims_per_batch', type=int, default=16)
    parser.add_argument('--num_dataloader_workers', type=int, default=1)
    parser.add_argument('--num_iters', type=int, default=3000)
    parser.add_argument('--base_lr', type=float, default=0.01)
    parser.add_argument('--lr_steps', type=str, default='1000,2000,3000,4000,5000,6000,7000,8000,9000')
    parser.add_argument('--gamma', type=float, default=0.2)
    parser.add_argument('--rpn_batch_size', type=int, default=64)
    parser.add_argument('--eval_rate', type=float, default=0.25)
    parser.add_argument('--sample_size', type=int, default=11)
    parser.add_argument("--eval_only", type=bool, default=False)
    # parser.add_argument("--ignore_display", dest="display", action="store_false", default=True)
#    parser.add_argument("--local_rank", default=0)
    parser.add_argument("--machine_rank", type=int, default=0)
#    parser.add_argument("--num_gpus", type=int, default=8)
#    parser.add_argument("--num_machines", type=int, default=1)
    parser.add_argument("--resume", type=str, default="False")
    parser.add_argument("--opts", type=list, default=[])
    parser.add_argument("--spot_ckpt", default='')
    args, unknown = parser.parse_known_args()
    return args, unknown
            