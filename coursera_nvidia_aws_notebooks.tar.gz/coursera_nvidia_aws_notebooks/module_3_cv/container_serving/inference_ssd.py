import json
import sys
import logging
import cv2
import numpy as np
import torch
import torchvision
from skimage import io, transform
from sagemaker_inference import content_types, decoder, default_inference_handler, encoder

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler(sys.stdout))


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
utils = torch.hub.load('NVIDIA/DeepLearningExamples:torchhub', 'nvidia_ssd_processing_utils')

def crop_center(img, cropx, cropy):
    """Code from Loading_Pretrained_Models.ipynb - a Caffe2 tutorial"""
    y, x, c = img.shape
    startx = x // 2 - (cropx // 2)
    starty = y // 2 - (cropy // 2)
    return img[starty:starty + cropy, startx:startx + cropx]

def normalize(img, mean=128, std=128):
    img = (img * 256 - mean) / std
    return img

def rescale(img, input_height, input_width):
    """Code from Loading_Pretrained_Models.ipynb - a Caffe2 tutorial"""
    aspect = img.shape[1] / float(img.shape[0])
    if (aspect > 1):
        # landscape orientation - wide image
        res = int(aspect * input_height)
        imgScaled = transform.resize(img, (input_width, res))
    if (aspect < 1):
        # portrait orientation - tall image
        res = int(input_width / aspect)
        imgScaled = transform.resize(img, (res, input_height))
    if (aspect == 1):
        imgScaled = transform.resize(img, (input_width, input_height))
    return imgScaled

def prepare_input(img):
    img = rescale(img, 300, 300)
    img = crop_center(img, 300, 300)
    img = normalize(img)
    return img

def prepare_tensor(inputs, fp16=False):
    NHWC = np.array(inputs)
    NCHW = np.swapaxes(np.swapaxes(NHWC, 1, 3), 2, 3)
    tensor = torch.from_numpy(NCHW)
    tensor = tensor.contiguous()
    if torch.cuda.is_available():
        tensor.cuda()
    tensor = tensor.float()
    if fp16:
        tensor = tensor.half()
    return tensor
        

def model_fn(model_dir):
    print(model_dir)
    model = torch.hub.load('NVIDIA/DeepLearningExamples:torchhub', 'nvidia_ssd', pretrained=False) 
    checkpoint = torch.hub.load_state_dict_from_url("https://api.ngc.nvidia.com/v2/models/nvidia/ssdpyt_fp32/versions/2/zip", 
                                                    map_location=device) 
    state_dict = {key.replace("module.", ""): value for key, value in checkpoint["model"].items()}
    model.load_state_dict(state_dict)
    model.eval()
    model.to(device)
    return model
    
    
def predict_fn(input_data, model):
    # run prediction
    print('input_data',input_data)
#     input_data = [utils.prepare_input(input_data)]
    input_data = [prepare_input(input_data)]
    tensor = utils.prepare_tensor(input_data)

    print('tensor shape',tensor.shape)
    with torch.no_grad():
        detections_batch = model(tensor)
    results_per_input = utils.decode_results(detections_batch)
    best_results_per_input = [utils.pick_best(results, 0.40) for results in results_per_input]
    print('Output results', best_results_per_input)
    return best_results_per_input

# just use the input_fn from the D2 endpoint 
def input_fn(request_body, request_content_type):
    """
    Converts image from NPY format to numpy.
    """
    logger.info(f"Handling inputs...Content type is {request_content_type}")
    
    try:
        if "application/x-npy" in request_content_type:
            input_object = decoder.decode(request_body, content_types.NPY)
        elif "jpeg" in request_content_type:
            nparr = np.frombuffer(request_body, np.uint8)
            print('orig shape:',nparr.shape)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            print('post decode shape:', img.shape)
            input_object = np.asarray(img, dtype=np.uint8)
            print('array shape', input_object.shape)
        else:
            raise Exception(f"Unsupported request content type {request_content_type}")
    except Exception as e:
        logger.error("Input deserialization failed...")
        logger.error(e)  
        return None
            
    logger.info("Input deserialization completed...")
    logger.info(f"Input object type is {type(input_object)} and shape {input_object.shape}")

    return input_object



def output_fn(prediction, response_content_type):
    logger.info('Raw prediction', prediction)
#     if response_content_type == 'application/json':
    bboxs = []
    oclasss = []
    probs = []
    for res in prediction:
        bbox = res[0].tolist()
        oclass = res[1].tolist()
        prob = res[2].tolist()
        bboxs.append(bbox)
        oclasss.append(oclass)
        probs.append(prob)

    out_json = {"bbox":bboxs,
    "class":oclasss,
    "probability":probs}
    output = json.dumps(out_json)
    return output
#     raise Exception('Requested unsupported ContentType in Accept: {}'.format(response_content_type))
    
# def output_fn(prediction, response_content_type):
    
#     logger.info("Processing output predictions...")
#     logger.debug(f"Output object type is {type(prediction)}")
        
#     try:
#         logger.info(f"response_content_type: {response_content_type}")
#         if "json" in response_content_type:
#             logger.debug('JSON processing -- d2_deserializer')
# #             output = d2_deserializer.d2_to_json(prediction)

#         elif "detectron2" in response_content_type:
#             logger.debug("check prediction before pickling")
#             logger.debug(type(prediction))
            
#             pickled_outputs = pickle.dumps(prediction)
#             stream = io.BytesIO(pickled_outputs)
#             output = stream.getvalue()
            
#         else:
#             raise Exception(f"Unsupported response content type {response_content_type}")
        
#     except Exception as e:
#         logger.error("Output processing failed...")
#         logger.error(e)
#         return None
    
#     logger.info("Output processing completed")
#     logger.debug(f"Predicted output type is {type(output)}")

#     return output