import numpy as np
import torch
import torchvision

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def model_fn(model_dir):
    print(model_dir)
    model = torchvision.models.detection.retinanet_resnet50_fpn(pretrained=False, num_classes=51)
    model.load_state_dict(torch.load(f'{model_dir}/model.pth', map_location=device))
    model.eval()
    model.to(device)
    return model
    
# def output_fn():


    
# this function tells the endpoint how to make predictions and how to package them to send back
def predict_fn(input_data, model):
    # run prediction
    with torch.no_grad():
        pred = model(input_data)
    return pred
        

# this function handles our input data and reshapes it back into an image
def input_fn(request_body, request_content_type):
    """this function handles our input data and reshapes it back into an image"""
    if(request_content_type == 'application/x-npy'):
        try:
            input_data = np.frombuffer(request_body, dtype=np.float32)
        except:
            input_data = np.array(request_body, dtype=np.float32)
    try:
        input_data = torch.tensor(np.reshape(input_data,(1,3,256,256)), dtype=torch.float32, device=device) # this needs to be a torch tensor 
    except:
        input_data = torch.tensor(np.reshape(input_data[32:],(1,3,256,256)), dtype=torch.float32, device=device) # this needs to be a torch tensor 
    return input_data


# this function loads our model weights from s3, or if that fails, from the NGC repo
# def model_fn(model_dir):
#     device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
#     model = SSD300(backbone=ResNet('resnet50'))
#     try:
#         model_weights = torch.load(os.path.join(model_dir, 'nvidia_ssdpyt_fp32_190826.pt'), map_location='cpu')['model']
#         model.to('cpu')
#         model.load_state_dict(model_weights)
#     except:
#         print('using fallback model loading')
#         os.system('wget https://api.ngc.nvidia.com/v2/models/nvidia/ssdpyt_fp32/versions/2/files/nvidia_ssdpyt_fp32_190826.pt')
#         model_weights = torch.load(os.path.join('nvidia_ssdpyt_fp32_190826.pt'), map_location='cpu')['model']
#         model.to('cpu')
#         model.load_state_dict(model_weights)
#     model.eval()
#     return model 